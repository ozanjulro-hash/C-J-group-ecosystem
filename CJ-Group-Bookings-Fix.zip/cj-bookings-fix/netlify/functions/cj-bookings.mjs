import { getStore } from '@netlify/blobs';
import { timingSafeEqual } from 'node:crypto';

const store = getStore({ name: 'cj-bookings', consistency: 'strong' });
const statuses = new Set(['Pending', 'Confirmed', 'Cancelled']);

// Imported from the existing C&J booking notification emails so they appear after first deployment.
const previousEmailBookings = [
  { id:'gmail-1a1baaa76ebd6d1e', customer_name:'Elisha kiprono', customer_phone:'725120868', customer_email:'jbett059@gmail.com', division:'C&J Haven (Hotel & Spa)', service_requested:'Luxury Presidential Suite (Per Night) (KES 35,000)', preferred_date:'2026-11-10', special_notes:'None', submitted_at:'2026-11-08T10:18:15Z', status:'Pending', source:'gmail-import' },
  { id:'gmail-1a1bab0edc957185', customer_name:'Emmanuel kiprono', customer_phone:'0112152740', customer_email:'kipronokz19@gmail.com', division:'C&J Healthcare (Hospital)', service_requested:'Comprehensive Executive Health Checkup (KES 15,000)', preferred_date:'2026-11-12', special_notes:'None', submitted_at:'2026-11-08T10:25:19Z', status:'Pending', source:'gmail-import' },
  { id:'gmail-1a1babf1c331d633', customer_name:'Julius bett', customer_phone:'0703749684', customer_email:'jbett059@gmail.com', division:'C&J Haven (Hotel & Spa)', service_requested:'Full-Day Conference Facility Package (KES 25,000)', preferred_date:'2026-11-14', special_notes:'30 members', submitted_at:'2026-11-08T10:40:49Z', status:'Pending', source:'gmail-import' },
  { id:'gmail-1a1bac26bf975c76', customer_name:'Felix cheruiyot', customer_phone:'0728148076', customer_email:'tsarvaevtonkins@gmail.com', division:'C&J Haven (Hotel & Spa)', service_requested:'Luxury Presidential Suite (Per Night) (KES 35,000)', preferred_date:'2026-11-18', special_notes:'Me and my wife,cool treatment', submitted_at:'2026-11-08T10:44:25Z', status:'Pending', source:'gmail-import' },
  { id:'gmail-1a1bcc91dcbece34', customer_name:'Joy cherotich', customer_phone:'0781612235', customer_email:'johnstone300t@gmail.com', division:'C&J Haven (Hotel & Spa)', service_requested:'Luxury Presidential Suite (Per Night) (KES 35,000)', preferred_date:'2026-11-09', special_notes:'None', submitted_at:'2026-11-08T20:10:58Z', status:'Pending', source:'gmail-import' },
  { id:'gmail-1a1bf5a88933c22a', customer_name:'Elizabeth kerich', customer_phone:'0725120868', customer_email:'lindagrace3467@gmail.com', division:'C&J Haven Hotel', service_requested:'A standard guest room', preferred_date:'2026-11-10', special_notes:'', submitted_at:'2026-11-09T08:08:49Z', status:'Pending', source:'gmail-import' }
];

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
  });
}

function isAdmin(req) {
  const expected = process.env.CJ_ADMIN_PASSWORD || '';
  const provided = req.headers.get('x-cj-admin-password') || '';
  if (!expected || !provided) return false;
  const a = Buffer.from(provided);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

async function seedPreviousBookings() {
  const marker = await store.get('meta:previous-email-import-v1', { type: 'text' });
  if (marker) return;
  for (const booking of previousEmailBookings) {
    await store.setJSON(`booking/${booking.id}`, booking);
  }
  await store.set('meta:previous-email-import-v1', new Date().toISOString());
}

export default async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204 });

  if (req.method === 'POST') {
    let body;
    try { body = await req.json(); } catch { return json({ error: 'Invalid booking data.' }, 400); }
    const booking = {
      id: crypto.randomUUID(),
      customer_name: String(body.customer_name || '').trim().slice(0, 120),
      customer_phone: String(body.customer_phone || '').trim().slice(0, 40),
      customer_email: String(body.customer_email || '').trim().slice(0, 160),
      division: String(body.division || '').trim().slice(0, 100),
      service_requested: String(body.service_requested || '').trim().slice(0, 180),
      preferred_date: String(body.preferred_date || '').trim().slice(0, 30),
      special_notes: String(body.special_notes || '').trim().slice(0, 1200),
      submitted_at: new Date().toISOString(),
      status: 'Pending',
      source: 'website'
    };
    if (!booking.customer_name || !booking.customer_phone || !booking.customer_email || !booking.division || !booking.service_requested || !booking.preferred_date) {
      return json({ error: 'Please complete all required booking details.' }, 400);
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(booking.customer_email)) return json({ error: 'Please enter a valid email address.' }, 400);
    await store.setJSON(`booking/${booking.id}`, booking);
    return json({ success: true, booking: { id: booking.id, status: booking.status } }, 201);
  }

  if (!isAdmin(req)) {
    if (!process.env.CJ_ADMIN_PASSWORD) return json({ error: 'The site owner must first set CJ_ADMIN_PASSWORD in Netlify environment variables.' }, 503);
    return json({ error: 'Incorrect dashboard password.' }, 401);
  }

  if (req.method === 'GET') {
    await seedPreviousBookings();
    const { blobs } = await store.list({ prefix: 'booking/' });
    const bookings = (await Promise.all(blobs.map(({ key }) => store.get(key, { type: 'json', consistency: 'strong' })))).filter(Boolean);
    bookings.sort((a, b) => String(b.submitted_at || '').localeCompare(String(a.submitted_at || '')));
    return json({ bookings });
  }

  if (req.method === 'PATCH') {
    let body;
    try { body = await req.json(); } catch { return json({ error: 'Invalid update.' }, 400); }
    const id = String(body.id || '');
    const status = String(body.status || '');
    if (!id || !statuses.has(status)) return json({ error: 'A valid booking ID and status are required.' }, 400);
    const key = `booking/${id}`;
    const booking = await store.get(key, { type: 'json', consistency: 'strong' });
    if (!booking) return json({ error: 'Booking not found.' }, 404);
    booking.status = status;
    booking.updated_at = new Date().toISOString();
    await store.setJSON(key, booking);
    return json({ success: true, booking });
  }

  return json({ error: 'Method not allowed.' }, 405);
};
