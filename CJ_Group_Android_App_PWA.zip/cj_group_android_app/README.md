# C&J Group Android app (PWA)

## What's included
- Installable Android Progressive Web App shell and app icons using the C&J logo already embedded in your dashboard.
- Customer area with C&J Healthcare, C&J Haven Hotel and C&J Gym information.
- Booking request form addressed to `ozanjulro@gmail.com`.
- Existing C&J management dashboard retained, including daily income by department, staff/payment tracking, booking inbox, and backup/restore.
- Offline app-shell caching.

## Install on Android
1. Upload the contents of this folder to an HTTPS website (not a `file://` link).
2. Open the website in Chrome on an Android phone.
3. Open Chrome's menu and choose **Install app** or **Add to Home screen**.
4. Launch C&J Group from the new home-screen icon.

## Important setup still required for live multi-device use
This package is the installable front end. It does **not** yet include a secure hosted database, administrator authentication, or the Gmail server integration. The old dashboard uses browser-local storage, so income and staff records stay on the device/browser where they were entered.

The customer form first attempts `POST /api/cj-bookings`. If the endpoint is not configured, it opens the customer's email app with a prepared booking email to `ozanjulro@gmail.com`; the customer must press Send. The existing management inbox reads `GET /api/cj-bookings`. To make customer bookings appear automatically for management, a secure backend must implement both routes and connect to the mailbox using server-side OAuth. Never put Gmail tokens or passwords in this HTML or in public JavaScript.

Before publishing publicly, add server-side administrator login/authorization to protect staff and financial records. A front-end-only PIN is not secure and is deliberately not represented as real authentication here.

## Files
- `index.html` — app and existing dashboard
- `manifest.webmanifest` — Android install metadata
- `service-worker.js` — app-shell offline cache
- `icons/` — 192px and 512px app icons
